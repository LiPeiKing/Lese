module.exports = {
  exts: [{
    name: 'import-postman'
  },{
    name: 'import-har'
  },{
    name: 'advanced-mock'
  },{
    name: 'import-swagger'
  },{
    name: 'statistics'
  },{
    name: 'export-data'
  },{
    name: 'gen-services'
  },{
    name: 'export-swagger2-data'
  },{
    name: 'import-yapi-json'
  },{
    name: 'wiki'
  }, {
    name: 'swagger-auto-sync'
  }
  // {
  //   name: 'test'
  // }
]
}